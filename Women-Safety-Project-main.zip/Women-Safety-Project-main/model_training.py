import joblib

# Load feature columns
feature_columns = joblib.load('feature_columns.pkl')

# Print the first few feature names
print("Feature Columns:", feature_columns[:10])

# Check if your city exists in the feature list
city_name = "Chennai"
city_encoded = f"City_{city_name}"
if city_encoded in feature_columns:
    print(f"✅ {city_name} exists in the model features.")
else:
    print(f"❌ {city_name} NOT found in model features.")
